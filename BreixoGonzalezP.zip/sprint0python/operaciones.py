
def suma(a, b):
    return a + b

def resta(a, b):
    return a - b

def multiplicación(a, b):
    return a * b

def división(a, b):
    if b != 0:
        return a / b
    else:
        return "Error: División por cero"